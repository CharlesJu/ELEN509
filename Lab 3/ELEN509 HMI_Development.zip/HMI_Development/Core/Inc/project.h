// Project.h


#ifndef PROJECT_H
#define PROJECT_H

#define true 1
#define false 0


typedef  enum {
  FORWARD,
  BACKWARD,
  STOPPED
}direction_indication ;

#endif